ChargEm Life Insurance Policy Quotation System
================================================

Author: Rojesh Shrestha
Course: CS 421
Date: September 8, 2026


DESCRIPTION
-----------
This program is a Java Swing graphical application designed for
ChargEm Life Insurance sales representatives.

The program collects customer information including name, age,
height, weight, and desired policy coverage. It calculates the
customer's insurance risk factor, determines whether the customer
is SAFE or UNSAFE, and calculates the annual insurance premium.

The program also supports percentage and flat-dollar discounts
and applies a 6% sales tax to the premium after discounts.


PROGRAM FILES
-------------
ChargEmInsurance.java
    Main application entry point.

InsuranceQuoteGUI.java
    Contains the graphical user interface, input validation,
    user interaction, and quote result display.

InsuranceCalculator.java
    Contains the insurance risk, premium, discount, tax,
    and final-total calculations.


JAVA REQUIREMENTS
-----------------
Java SE / JDK 26

The program was developed and tested using:

Java 26.0.2
javac 26.0.2


COMPILING THE PROGRAM
---------------------
Open a command-line terminal and navigate to the folder containing
the program files.

Compile the program with:

javac ChargEmInsurance.java InsuranceQuoteGUI.java InsuranceCalculator.java


RUNNING THE PROGRAM
-------------------
After successful compilation, run:

java ChargEmInsurance


The ChargEm Life Insurance Quote graphical interface will open.


PROGRAM FEATURES
----------------
- Separate first name, optional middle initial, and last name fields
- Customer age, height, weight, and coverage input
- Insurance risk factor calculation
- SAFE and UNSAFE risk classification
- Annual premium calculation
- Cost per $1,000 of coverage
- No-discount option
- Percentage discount option
- Flat-dollar discount option
- 6% sales tax calculation
- Final annual policy total
- Input validation and error messages
- Clear button for resetting the quotation form
