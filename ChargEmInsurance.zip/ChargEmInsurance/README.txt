ChargEm Life Insurance Policy Quotation System
================================================

Author: Rojesh Shrestha
Course: CS 421
Date: September 8, 2026


DESCRIPTION
-----------
The ChargEm Life Insurance Policy Quotation System is a Java Swing
graphical application designed for ChargEm Life Insurance sales
representatives.

The program collects customer information including first name,
optional middle initial, last name, age, height, weight, and desired
policy coverage amount.

Using the customer's information, the program calculates the insurance
risk factor, determines whether the customer is classified as SAFE or
UNSAFE, and calculates the annual insurance premium.

The program also supports percentage and flat-dollar discounts. After
any discount is applied, a 6% sales tax is calculated and added to the
premium to determine the final annual policy total.


PROGRAM FILES
-------------
ChargEmInsurance.java
    Contains the main method and starts the application.

InsuranceQuoteGUI.java
    Contains the Java Swing graphical user interface, input validation,
    discount handling, and quotation result display.

InsuranceCalculator.java
    Contains the insurance risk factor, premium, discount, sales tax,
    and final-total calculations.


JAVA REQUIREMENTS
-----------------
Java SE / JDK 25

The program is designed to run in the SE 145 Java environment and
has been successfully compiled and tested in the SE 145 lab.


COMPILING THE PROGRAM
---------------------
The program can be compiled from the command line without using
an IDE.

1. Open Command Prompt or another command-line terminal.

2. Navigate to the folder containing the Java source files.

3. Compile the program using:

javac ChargEmInsurance.java InsuranceQuoteGUI.java InsuranceCalculator.java

If compilation is successful, the command will complete without
displaying an error message.


RUNNING THE PROGRAM
-------------------
After successful compilation, run the application using:

java ChargEmInsurance

The ChargEm Life Insurance Quote graphical interface will open.


PROGRAM FEATURES
----------------
- Java Swing graphical user interface
- Separate first name, optional middle initial, and last name fields
- Customer age, height, and weight input
- Desired insurance policy coverage input
- Insurance risk factor calculation
- SAFE and UNSAFE risk classification
- Risk factor normalization when required
- Annual insurance premium calculation
- Cost per $1,000 of coverage
- No-discount option
- Percentage discount option
- Flat-dollar discount option
- 6% sales tax calculation after discounts
- Final annual policy total
- Input validation and error messages
- Clear button to reset the quotation form


INPUT VALIDATION
----------------
The program checks for invalid or missing input, including:

- Missing first or last name
- Invalid middle initial
- Non-numeric values in numeric fields
- Age, height, weight, or coverage values that are not greater than zero
- Invalid risk-factor calculations
- Percentage discounts outside the range of 0 to 100
- Negative flat-dollar discounts
- Flat-dollar discounts greater than the annual premium


TESTING
-------
The program was successfully compiled and executed using the Java
environment installed in the SE 145 computer lab.

The following functionality was tested:

- Customer information entry
- Risk factor calculations
- SAFE and UNSAFE classifications
- Risk factor normalization
- No-discount quotations
- Percentage discounts
- Flat-dollar discounts
- Sales tax calculations
- Final policy total calculations
- Invalid input handling
- Clear/reset functionality


NOTES
-----
The application uses Java Swing for its graphical user interface.

No IDE is required to compile or run the program. The application can
be compiled and executed entirely from the command line using the
commands provided above.