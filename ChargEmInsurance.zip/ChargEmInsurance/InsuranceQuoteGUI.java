import javax.swing.*;
import java.awt.*;
import java.text.NumberFormat;

/*
 * ChargEm Life Insurance Policy Quotation System
 *
 * Course: CS 421
 * Date: September 8, 2026
 */

/**
 * Provides the graphical user interface for the ChargEm Life Insurance
 * quotation system.
 *
 * <p>This class is responsible for collecting customer information,
 * validating user input, processing discount selections, requesting
 * insurance calculations, and displaying the completed quotation.</p>
 *
 * @author Rojesh Shrestha
 */
public class InsuranceQuoteGUI {

    // Main application window
    private JFrame frame;

    // Customer and policy input fields
    private JTextField firstNameField;
    private JTextField middleInitialField;
    private JTextField lastNameField;
    private JTextField ageField;
    private JTextField heightField;
    private JTextField weightField;
    private JTextField coverageField;
    private JTextField discountAmountField;

    // Discount selection controls
    private JRadioButton noDiscountButton;
    private JRadioButton percentDiscountButton;
    private JRadioButton flatDiscountButton;

    // Quote result labels
    private JLabel customerResultLabel;
    private JLabel riskFactorResultLabel;
    private JLabel riskStatusResultLabel;
    private JLabel coverageResultLabel;
    private JLabel costPerThousandResultLabel;
    private JLabel annualPremiumResultLabel;
    private JLabel discountResultLabel;
    private JLabel salesTaxResultLabel;
    private JLabel finalTotalResultLabel;

    /**
     * Constructs and initializes the quotation interface.
     */
    public InsuranceQuoteGUI() {
        createGUI();
    }

    /**
     * Displays the application window.
     */
    public void show() {
        frame.setVisible(true);
    }

    /**
     * Creates the main application window, panels, controls,
     * and event handlers.
     */
    private void createGUI() {

        frame = new JFrame("ChargEm Life Insurance Quote");
        frame.setSize(900, 650);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(
                new BorderLayout(15, 15)
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 15, 15, 15
                )
        );

        // Panel containing customer and policy input controls
        JPanel inputPanel = new JPanel(
                new GridLayout(10, 2, 10, 10)
        );

        inputPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Customer Information"
                )
        );

        // Panel containing calculated quotation results
        JPanel resultPanel = new JPanel(
                new GridLayout(9, 1, 8, 8)
        );

        resultPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Quote Results"
                )
        );

        JPanel buttonPanel = new JPanel();

        createInputFields();
        createDiscountControls();
        createResultLabels();

        JButton calculateButton =
                new JButton("Calculate Quote");

        JButton clearButton =
                new JButton("Clear");

        addInputComponents(inputPanel);
        addResultComponents(resultPanel);

        buttonPanel.add(calculateButton);
        buttonPanel.add(clearButton);

        panel.add(inputPanel, BorderLayout.WEST);
        panel.add(resultPanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        configureDiscountActions();

        calculateButton.addActionListener(
                e -> calculateQuote()
        );

        clearButton.addActionListener(
                e -> clearForm()
        );

        frame.add(panel);
    }

    /**
     * Creates the text fields used to collect customer and
     * policy information.
     */
    private void createInputFields() {

        firstNameField = new JTextField();
        middleInitialField = new JTextField();
        lastNameField = new JTextField();

        ageField = new JTextField();
        heightField = new JTextField();
        weightField = new JTextField();
        coverageField = new JTextField();

        discountAmountField = new JTextField();
    }

    /**
     * Creates and groups the available discount options.
     * No discount is selected by default.
     */
    private void createDiscountControls() {

        noDiscountButton =
                new JRadioButton("No Discount");

        percentDiscountButton =
                new JRadioButton("Percentage Discount");

        flatDiscountButton =
                new JRadioButton("Flat Dollar Discount");

        ButtonGroup discountGroup =
                new ButtonGroup();

        discountGroup.add(noDiscountButton);
        discountGroup.add(percentDiscountButton);
        discountGroup.add(flatDiscountButton);

        noDiscountButton.setSelected(true);
        discountAmountField.setEnabled(false);
    }

    /**
     * Creates the labels used to display quotation results.
     */
    private void createResultLabels() {

        customerResultLabel =
                new JLabel("Customer:");

        riskFactorResultLabel =
                new JLabel("Risk Factor:");

        riskStatusResultLabel =
                new JLabel("Risk Status:");

        coverageResultLabel =
                new JLabel("Coverage Amount:");

        costPerThousandResultLabel =
                new JLabel("Cost per $1,000:");

        annualPremiumResultLabel =
                new JLabel("Annual Premium:");

        discountResultLabel =
                new JLabel("Discount:");

        salesTaxResultLabel =
                new JLabel("Sales Tax (6%):");

        finalTotalResultLabel =
                new JLabel("FINAL TOTAL:");

        // Emphasize the final quotation amount.
        finalTotalResultLabel.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        18
                )
        );
    }

    /**
     * Adds customer, policy, and discount controls to the
     * customer information panel.
     *
     * @param inputPanel panel that receives the input controls
     */
    private void addInputComponents(
            JPanel inputPanel) {

        inputPanel.add(
                new JLabel("First Name:")
        );
        inputPanel.add(firstNameField);

        inputPanel.add(
                new JLabel("Middle Initial:")
        );
        inputPanel.add(middleInitialField);

        inputPanel.add(
                new JLabel("Last Name:")
        );
        inputPanel.add(lastNameField);

        inputPanel.add(
                new JLabel("Age:")
        );
        inputPanel.add(ageField);

        inputPanel.add(
                new JLabel("Height (inches):")
        );
        inputPanel.add(heightField);

        inputPanel.add(
                new JLabel("Weight (lbs):")
        );
        inputPanel.add(weightField);

        inputPanel.add(
                new JLabel("Coverage Amount:")
        );
        inputPanel.add(coverageField);

        inputPanel.add(
                new JLabel("Discount Type:")
        );
        inputPanel.add(noDiscountButton);

        inputPanel.add(percentDiscountButton);
        inputPanel.add(flatDiscountButton);

        inputPanel.add(
                new JLabel("Discount Amount:")
        );
        inputPanel.add(discountAmountField);
    }

    /**
     * Adds all quotation result labels to the results panel.
     *
     * @param resultPanel panel that receives the result labels
     */
    private void addResultComponents(
            JPanel resultPanel) {

        resultPanel.add(customerResultLabel);
        resultPanel.add(riskFactorResultLabel);
        resultPanel.add(riskStatusResultLabel);
        resultPanel.add(coverageResultLabel);
        resultPanel.add(costPerThousandResultLabel);
        resultPanel.add(annualPremiumResultLabel);
        resultPanel.add(discountResultLabel);
        resultPanel.add(salesTaxResultLabel);
        resultPanel.add(finalTotalResultLabel);
    }

    /**
     * Configures the behavior of the discount radio buttons.
     * The discount amount field is enabled only when a
     * percentage or flat-dollar discount is selected.
     */
    private void configureDiscountActions() {

        noDiscountButton.addActionListener(
                e -> {
                    discountAmountField.setText("");
                    discountAmountField.setEnabled(false);
                }
        );

        percentDiscountButton.addActionListener(
                e -> {
                    discountAmountField.setEnabled(true);
                    discountAmountField.setText("");
                    discountAmountField.requestFocus();
                }
        );

        flatDiscountButton.addActionListener(
                e -> {
                    discountAmountField.setEnabled(true);
                    discountAmountField.setText("");
                    discountAmountField.requestFocus();
                }
        );
    }

    /**
     * Reads and validates user input, requests the required
     * insurance calculations, applies any selected discount,
     * and displays the completed quotation.
     */
    private void calculateQuote() {

        try {

            // Read and clean customer name information.
            String firstName =
                    firstNameField
                            .getText()
                            .trim();

            String middleInitial =
                    middleInitialField
                            .getText()
                            .trim();

            String lastName =
                    lastNameField
                            .getText()
                            .trim();

            // First and last names are required.
            if (firstName.isEmpty()) {

                showMessage(
                        "Please enter the customer's first name."
                );

                return;
            }

            // Middle initial is optional, but must be one letter if supplied.
            if (!middleInitial.isEmpty()
                    && (
                    middleInitial.length() != 1
                            || !Character.isLetter(
                            middleInitial.charAt(0)
                    )
            )) {

                showMessage(
                        "Middle initial must be one letter or left blank."
                );

                return;
            }

            if (lastName.isEmpty()) {

                showMessage(
                        "Please enter the customer's last name."
                );

                return;
            }

            // Convert numeric text fields into values used for calculations.
            int age =
                    Integer.parseInt(
                            ageField
                                    .getText()
                                    .trim()
                    );

            double height =
                    Double.parseDouble(
                            heightField
                                    .getText()
                                    .trim()
                    );

            double weight =
                    Double.parseDouble(
                            weightField
                                    .getText()
                                    .trim()
                    );

            double coverage =
                    Double.parseDouble(
                            coverageField
                                    .getText()
                                    .trim()
                    );

            // Customer and policy values must be positive.
            if (age <= 0) {

                showMessage(
                        "Age must be greater than 0."
                );

                return;
            }

            if (height <= 0) {

                showMessage(
                        "Height must be greater than 0."
                );

                return;
            }

            if (weight <= 0) {

                showMessage(
                        "Weight must be greater than 0."
                );

                return;
            }

            if (coverage <= 0) {

                showMessage(
                        "Coverage amount must be greater than $0."
                );

                return;
            }

            /*
             * The risk-factor formula contains this expression in
             * its denominator. A value near zero would make the
             * calculation invalid.
             */
            double denominator =
                    weight - (4.01 * age);

            if (Math.abs(denominator)
                    < 0.000001) {

                showMessage(
                        "These age and weight values cause an invalid risk calculation."
                );

                return;
            }

            // Calculate the customer's insurance risk factor.
            double riskFactor =
                    InsuranceCalculator
                            .calculateRiskFactor(
                                    age,
                                    height,
                                    weight
                            );

            String riskStatus;

            if (riskFactor >= 0) {
                riskStatus = "Safe";
            } else {
                riskStatus = "Unsafe";
            }

            // Normalize the risk factor before calculating the premium.
            double adjustedRiskFactor =
                    InsuranceCalculator
                            .adjustRiskFactor(
                                    riskFactor
                            );

            double annualPremium =
                    InsuranceCalculator
                            .calculateAnnualPremium(
                                    adjustedRiskFactor,
                                    coverage
                            );

            double costPerThousand =
                    InsuranceCalculator
                            .calculateCostPerThousand(
                                    annualPremium,
                                    coverage
                            );

            // Start with the full premium before applying a discount.
            double discountAmount = 0.0;
            double premiumAfterDiscount =
                    annualPremium;

            // Process a percentage discount when selected.
            if (percentDiscountButton
                    .isSelected()) {

                double percentDiscount =
                        Double.parseDouble(
                                discountAmountField
                                        .getText()
                                        .trim()
                        );

                if (percentDiscount < 0
                        || percentDiscount > 100) {

                    showMessage(
                            "Percentage discount must be between 0 and 100."
                    );

                    return;
                }

                discountAmount =
                        InsuranceCalculator
                                .calculatePercentageDiscount(
                                        annualPremium,
                                        percentDiscount
                                );

                premiumAfterDiscount =
                        annualPremium
                                - discountAmount;
            }

            // Process a flat-dollar discount when selected.
            else if (flatDiscountButton
                    .isSelected()) {

                discountAmount =
                        Double.parseDouble(
                                discountAmountField
                                        .getText()
                                        .trim()
                        );

                if (discountAmount < 0) {

                    showMessage(
                            "Flat dollar discount cannot be negative."
                    );

                    return;
                }

                if (discountAmount
                        > annualPremium) {

                    showMessage(
                            "Flat dollar discount cannot be greater than the annual premium."
                    );

                    return;
                }

                premiumAfterDiscount =
                        annualPremium
                                - discountAmount;
            }

            // Tax is applied after any discount has been deducted.
            double salesTax =
                    InsuranceCalculator
                            .calculateSalesTax(
                                    premiumAfterDiscount
                            );

            double finalTotal =
                    InsuranceCalculator
                            .calculateFinalTotal(
                                    premiumAfterDiscount,
                                    salesTax
                            );

            NumberFormat currency =
                    NumberFormat
                            .getCurrencyInstance();

            String fullName =
                    buildFullName(
                            firstName,
                            middleInitial,
                            lastName
                    );

            // Display the completed quotation.
            customerResultLabel.setText(
                    "Customer: "
                            + fullName
            );

            riskFactorResultLabel.setText(
                    String.format(
                            "Risk Factor: %.2f",
                            riskFactor
                    )
            );

            riskStatusResultLabel.setText(
                    "Risk Status: "
                            + riskStatus.toUpperCase()
            );

            coverageResultLabel.setText(
                    "Coverage Amount: "
                            + currency.format(
                            coverage
                    )
            );

            costPerThousandResultLabel.setText(
                    "Cost per $1,000: "
                            + currency.format(
                            costPerThousand
                    )
            );

            annualPremiumResultLabel.setText(
                    "Annual Premium: "
                            + currency.format(
                            annualPremium
                    )
            );

            discountResultLabel.setText(
                    "Discount: "
                            + currency.format(
                            discountAmount
                    )
            );

            salesTaxResultLabel.setText(
                    "Sales Tax (6%): "
                            + currency.format(
                            salesTax
                    )
            );

            finalTotalResultLabel.setText(
                    "FINAL TOTAL: "
                            + currency.format(
                            finalTotal
                    )
            );

        } catch (NumberFormatException ex) {

            /*
             * Handles blank or nonnumeric values entered into
             * fields that require numbers.
             */
            showMessage(
                    "Please enter valid numbers for age, height, weight, coverage, and discount."
            );
        }
    }

    /**
     * Restores the form to its initial state by clearing all
     * customer information, discount selections, and quote results.
     */
    private void clearForm() {

        firstNameField.setText("");
        middleInitialField.setText("");
        lastNameField.setText("");

        ageField.setText("");
        heightField.setText("");
        weightField.setText("");
        coverageField.setText("");

        discountAmountField.setText("");

        noDiscountButton.setSelected(true);
        discountAmountField.setEnabled(false);

        customerResultLabel.setText("Customer:");
        riskFactorResultLabel.setText("Risk Factor:");
        riskStatusResultLabel.setText("Risk Status:");
        coverageResultLabel.setText("Coverage Amount:");
        costPerThousandResultLabel.setText("Cost per $1,000:");
        annualPremiumResultLabel.setText("Annual Premium:");
        discountResultLabel.setText("Discount:");
        salesTaxResultLabel.setText("Sales Tax (6%):");
        finalTotalResultLabel.setText("FINAL TOTAL:");

        // Return keyboard focus to the first input field.
        firstNameField.requestFocus();
    }

    /**
     * Builds the customer's display name. The middle initial is
     * included only when one has been entered.
     *
     * @param firstName     customer's first name
     * @param middleInitial customer's optional middle initial
     * @param lastName      customer's last name
     * @return formatted customer name
     */
    private String buildFullName(
            String firstName,
            String middleInitial,
            String lastName) {

        if (middleInitial.isEmpty()) {
            return firstName
                    + " "
                    + lastName;
        }

        return firstName
                + " "
                + middleInitial.toUpperCase()
                + ". "
                + lastName;
    }

    /**
     * Displays an informational or validation message to the user.
     *
     * @param message message to display
     */
    private void showMessage(
            String message) {

        JOptionPane.showMessageDialog(
                frame,
                message
        );
    }
}