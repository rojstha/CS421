import javax.swing.*;
import java.awt.*;
import java.text.NumberFormat;

// FILENAME: InsuranceQuoteGUI.java
//
// WRITTEN BY: Rojesh Shrestha
// DATE CREATED: September 8, 2026
//
// PART OF PROJECT: ChargEm Life Insurance Policy Quotation System
//
// FILE PURPOSE:
// This file contains the main graphical user interface and the processing
// logic associated with customer input, validation, discounts, and quote
// display.
//
// CLASS NAME:
// InsuranceQuoteGUI
//
// WRITTEN BY: Rojesh Shrestha
// DATE CREATED: September 8, 2026
//
// CLASS PURPOSE:
// This class creates the graphical user interface used by ChargEm Life
// Insurance sales representatives. Customer and policy information is
// collected through this interface. The class validates the information,
// requests insurance calculations from the InsuranceCalculator class,
// processes discount selections, and displays the completed quotation.
//
// CLASS VARIABLE DICTIONARY (in Alphabetical Order):
// ageField                    - Text field used to enter customer age.
// annualPremiumResultLabel    - Label displaying the annual premium.
// costPerThousandResultLabel  - Label displaying cost per $1,000 of coverage.
// coverageField               - Text field used to enter requested coverage.
// coverageResultLabel         - Label displaying requested coverage amount.
// customerResultLabel         - Label displaying the customer's full name.
// discountAmountField         - Text field used to enter discount amount.
// discountResultLabel         - Label displaying the calculated discount.
// finalTotalResultLabel       - Label displaying the final annual policy total.
// firstNameField              - Text field used to enter customer's first name.
// flatDiscountButton          - Radio button for a flat-dollar discount.
// frame                       - Main application window.
// heightField                 - Text field used to enter customer height.
// lastNameField               - Text field used to enter customer's last name.
// middleInitialField          - Text field used to enter optional middle initial.
// noDiscountButton            - Radio button indicating no discount.
// percentDiscountButton       - Radio button for percentage discount.
// riskFactorResultLabel       - Label displaying the calculated risk factor.
// riskStatusResultLabel       - Label displaying SAFE or UNSAFE classification.
// salesTaxResultLabel         - Label displaying calculated sales tax.
// weightField                 - Text field used to enter customer weight.
//
// MODIFICATION HISTORY:
// WHO                 WHEN                WHAT
// ------------------  ------------------  ------------------------------------
// Rojesh Shrestha     September 8, 2026   Initial program implementation
//

public class InsuranceQuoteGUI {

    // VARIABLES -- VARIABLES -- VARIABLES -- VARIABLES -- VARIABLES
    // VARIABLES -- VARIABLES -- VARIABLES -- VARIABLES -- VARIABLES

    private JFrame frame;

    private JTextField firstNameField;
    private JTextField middleInitialField;
    private JTextField lastNameField;
    private JTextField ageField;
    private JTextField heightField;
    private JTextField weightField;
    private JTextField coverageField;
    private JTextField discountAmountField;

    private JRadioButton noDiscountButton;
    private JRadioButton percentDiscountButton;
    private JRadioButton flatDiscountButton;

    private JLabel customerResultLabel;
    private JLabel riskFactorResultLabel;
    private JLabel riskStatusResultLabel;
    private JLabel coverageResultLabel;
    private JLabel costPerThousandResultLabel;
    private JLabel annualPremiumResultLabel;
    private JLabel discountResultLabel;
    private JLabel salesTaxResultLabel;
    private JLabel finalTotalResultLabel;


    // METHODS/FUNCTIONS -- METHODS/FUNCTIONS -- METHODS/FUNCTIONS
    // METHODS/FUNCTIONS -- METHODS/FUNCTIONS -- METHODS/FUNCTIONS


    // METHOD NAME:
    // InsuranceQuoteGUI (CONSTRUCTOR)
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This is the default constructor for the InsuranceQuoteGUI class.
    // It creates and initializes the application's graphical interface.
    //
    // PARAMETERS LIST (in Parameter Order):
    // (None)
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    public InsuranceQuoteGUI() {

        createGUI();
    }


    // METHOD NAME:
    // show
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine displays the application's main graphical window.
    //
    // PARAMETERS LIST (in Parameter Order):
    // (None)
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    public void show() {

        frame.setVisible(true);
    }


    // METHOD NAME:
    // createGUI
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine creates the application's main window, input panel,
    // quotation results panel, command buttons, and event handlers.
    //
    // PARAMETERS LIST (in Parameter Order):
    // (None)
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // buttonPanel     - JPanel containing Calculate Quote and Clear buttons.
    // calculateButton - JButton used to calculate an insurance quotation.
    // clearButton     - JButton used to reset the application form.
    // inputPanel      - JPanel containing customer and policy input controls.
    // panel           - Main JPanel containing all sections of the interface.
    // resultPanel     - JPanel containing quotation output labels.
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private void createGUI() {

        // Create the main application window.
        frame =
                new JFrame(
                        "ChargEm Life Insurance Quote"
                );

        frame.setSize(900, 650);

        frame.setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        frame.setLocationRelativeTo(null);

        // Create the primary application panel.
        JPanel panel =
                new JPanel(
                        new BorderLayout(15, 15)
                );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        15,
                        15,
                        15,
                        15
                )
        );

        // Create the panel that contains customer information.
        JPanel inputPanel =
                new JPanel(
                        new GridLayout(
                                10,
                                2,
                                10,
                                10
                        )
                );

        inputPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Customer Information"
                )
        );

        // Create the panel that displays quotation results.
        JPanel resultPanel =
                new JPanel(
                        new GridLayout(
                                9,
                                1,
                                8,
                                8
                        )
                );

        resultPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Quote Results"
                )
        );

        // Create the panel containing application command buttons.
        JPanel buttonPanel =
                new JPanel();

        createInputFields();
        createDiscountControls();
        createResultLabels();

        JButton calculateButton =
                new JButton(
                        "Calculate Quote"
                );

        JButton clearButton =
                new JButton(
                        "Clear"
                );

        addInputComponents(
                inputPanel
        );

        addResultComponents(
                resultPanel
        );

        buttonPanel.add(
                calculateButton
        );

        buttonPanel.add(
                clearButton
        );

        panel.add(
                inputPanel,
                BorderLayout.WEST
        );

        panel.add(
                resultPanel,
                BorderLayout.CENTER
        );

        panel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        configureDiscountActions();

        // Calculate a quotation when the Calculate Quote button is clicked.
        calculateButton.addActionListener(
                e -> calculateQuote()
        );

        // Reset the form when the Clear button is clicked.
        clearButton.addActionListener(
                e -> clearForm()
        );

        frame.add(panel);
    }


    // METHOD NAME:
    // createInputFields
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine creates all text fields used to collect customer,
    // policy, and discount information.
    //
    // PARAMETERS LIST (in Parameter Order):
    // (None)
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private void createInputFields() {

        firstNameField =
                new JTextField();

        middleInitialField =
                new JTextField();

        lastNameField =
                new JTextField();

        ageField =
                new JTextField();

        heightField =
                new JTextField();

        weightField =
                new JTextField();

        coverageField =
                new JTextField();

        discountAmountField =
                new JTextField();
    }


    // METHOD NAME:
    // createDiscountControls
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine creates the three discount selection radio buttons and
    // groups them so only one discount option can be selected at a time.
    //
    // PARAMETERS LIST (in Parameter Order):
    // (None)
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // discountGroup - ButtonGroup that ensures the discount radio buttons
    //                 are mutually exclusive.
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private void createDiscountControls() {

        noDiscountButton =
                new JRadioButton(
                        "No Discount"
                );

        percentDiscountButton =
                new JRadioButton(
                        "Percentage Discount"
                );

        flatDiscountButton =
                new JRadioButton(
                        "Flat Dollar Discount"
                );

        ButtonGroup discountGroup =
                new ButtonGroup();

        discountGroup.add(
                noDiscountButton
        );

        discountGroup.add(
                percentDiscountButton
        );

        discountGroup.add(
                flatDiscountButton
        );

        // Begin with no discount selected.
        noDiscountButton.setSelected(true);

        // Discount amount is not needed when no discount is selected.
        discountAmountField.setEnabled(false);
    }


    // METHOD NAME:
    // createResultLabels
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine creates all labels used to display the calculated
    // quotation results.
    //
    // PARAMETERS LIST (in Parameter Order):
    // (None)
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private void createResultLabels() {

        customerResultLabel =
                new JLabel(
                        "Customer:"
                );

        riskFactorResultLabel =
                new JLabel(
                        "Risk Factor:"
                );

        riskStatusResultLabel =
                new JLabel(
                        "Risk Status:"
                );

        coverageResultLabel =
                new JLabel(
                        "Coverage Amount:"
                );

        costPerThousandResultLabel =
                new JLabel(
                        "Cost per $1,000:"
                );

        annualPremiumResultLabel =
                new JLabel(
                        "Annual Premium:"
                );

        discountResultLabel =
                new JLabel(
                        "Discount:"
                );

        salesTaxResultLabel =
                new JLabel(
                        "Sales Tax (6%):"
                );

        finalTotalResultLabel =
                new JLabel(
                        "FINAL TOTAL:"
                );

        // Make the final policy total visually prominent.
        finalTotalResultLabel.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        18
                )
        );
    }


    // METHOD NAME:
    // addInputComponents
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine places all customer, policy, and discount controls into
    // the customer information panel.
    //
    // PARAMETERS LIST (in Parameter Order):
    // inputPanel - JPanel that receives the input controls.
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private void addInputComponents(
            JPanel inputPanel) {

        inputPanel.add(
                new JLabel("First Name:")
        );

        inputPanel.add(
                firstNameField
        );

        inputPanel.add(
                new JLabel("Middle Initial:")
        );

        inputPanel.add(
                middleInitialField
        );

        inputPanel.add(
                new JLabel("Last Name:")
        );

        inputPanel.add(
                lastNameField
        );

        inputPanel.add(
                new JLabel("Age:")
        );

        inputPanel.add(
                ageField
        );

        inputPanel.add(
                new JLabel("Height (inches):")
        );

        inputPanel.add(
                heightField
        );

        inputPanel.add(
                new JLabel("Weight (lbs):")
        );

        inputPanel.add(
                weightField
        );

        inputPanel.add(
                new JLabel("Coverage Amount:")
        );

        inputPanel.add(
                coverageField
        );

        inputPanel.add(
                new JLabel("Discount Type:")
        );

        inputPanel.add(
                noDiscountButton
        );

        inputPanel.add(
                percentDiscountButton
        );

        inputPanel.add(
                flatDiscountButton
        );

        inputPanel.add(
                new JLabel("Discount Amount:")
        );

        inputPanel.add(
                discountAmountField
        );
    }


    // METHOD NAME:
    // addResultComponents
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine places all quotation result labels into the results panel.
    //
    // PARAMETERS LIST (in Parameter Order):
    // resultPanel - JPanel that receives the quotation result labels.
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private void addResultComponents(
            JPanel resultPanel) {

        resultPanel.add(
                customerResultLabel
        );

        resultPanel.add(
                riskFactorResultLabel
        );

        resultPanel.add(
                riskStatusResultLabel
        );

        resultPanel.add(
                coverageResultLabel
        );

        resultPanel.add(
                costPerThousandResultLabel
        );

        resultPanel.add(
                annualPremiumResultLabel
        );

        resultPanel.add(
                discountResultLabel
        );

        resultPanel.add(
                salesTaxResultLabel
        );

        resultPanel.add(
                finalTotalResultLabel
        );
    }


    // METHOD NAME:
    // configureDiscountActions
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine controls the behavior of the discount amount text field.
    // The field is disabled when no discount is selected and enabled when
    // either percentage or flat-dollar discount is selected.
    //
    // PARAMETERS LIST (in Parameter Order):
    // (None)
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private void configureDiscountActions() {

        noDiscountButton.addActionListener(
                e -> {

                    discountAmountField.setText("");

                    discountAmountField.setEnabled(
                            false
                    );
                }
        );

        percentDiscountButton.addActionListener(
                e -> {

                    discountAmountField.setEnabled(
                            true
                    );

                    discountAmountField.setText("");

                    discountAmountField.requestFocus();
                }
        );

        flatDiscountButton.addActionListener(
                e -> {

                    discountAmountField.setEnabled(
                            true
                    );

                    discountAmountField.setText("");

                    discountAmountField.requestFocus();
                }
        );
    }


    // METHOD NAME:
    // calculateQuote
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine collects information entered by the user, validates the
    // values, calculates the customer's insurance quotation, applies any
    // selected discount, calculates sales tax, and displays the final quote.
    //
    // PARAMETERS LIST (in Parameter Order):
    // (None)
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // adjustedRiskFactor   - Risk factor adjusted into the required range.
    // age                  - Customer's age in years.
    // annualPremium        - Calculated annual policy premium.
    // costPerThousand      - Calculated cost per $1,000 of policy coverage.
    // coverage             - Requested insurance policy coverage amount.
    // currency             - NumberFormat object used to display currency.
    // denominator          - Denominator used in the risk factor formula.
    // discountAmount       - Dollar amount of discount applied to premium.
    // finalTotal           - Final annual total after discount and sales tax.
    // firstName            - Customer's first name.
    // fullName             - Customer's formatted full name.
    // height               - Customer's height in inches.
    // lastName             - Customer's last name.
    // middleInitial        - Customer's optional middle initial.
    // percentDiscount      - Percentage discount entered by salesperson.
    // premiumAfterDiscount - Premium remaining after discount.
    // riskFactor           - Customer's calculated insurance risk factor.
    // riskStatus           - SAFE or UNSAFE classification.
    // salesTax             - Calculated Michigan sales tax.
    // weight               - Customer's weight in pounds.
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private void calculateQuote() {

        try {

            // Pull customer name information from the input fields.
            String firstName =
                    firstNameField
                            .getText()
                            .trim();

            String middleInitial =
                    middleInitialField
                            .getText()
                            .trim();

            String lastName =
                    lastNameField
                            .getText()
                            .trim();

            // Verify that a first name was entered.
            if (firstName.isEmpty()) {

                showMessage(
                        "Please enter the customer's first name."
                );

                return;
            }

            // A middle initial is optional, but when entered it must consist
            // of exactly one alphabetic character.
            if (!middleInitial.isEmpty()
                    && (
                    middleInitial.length() != 1
                            || !Character.isLetter(
                            middleInitial.charAt(0)
                    )
            )) {

                showMessage(
                        "Middle initial must be one letter or left blank."
                );

                return;
            }

            // Verify that a last name was entered.
            if (lastName.isEmpty()) {

                showMessage(
                        "Please enter the customer's last name."
                );

                return;
            }

            // Convert numeric text input to numeric data types.
            int age =
                    Integer.parseInt(
                            ageField
                                    .getText()
                                    .trim()
                    );

            double height =
                    Double.parseDouble(
                            heightField
                                    .getText()
                                    .trim()
                    );

            double weight =
                    Double.parseDouble(
                            weightField
                                    .getText()
                                    .trim()
                    );

            double coverage =
                    Double.parseDouble(
                            coverageField
                                    .getText()
                                    .trim()
                    );

            // Validate all numeric customer and policy values.
            if (age <= 0) {

                showMessage(
                        "Age must be greater than 0."
                );

                return;
            }

            if (height <= 0) {

                showMessage(
                        "Height must be greater than 0."
                );

                return;
            }

            if (weight <= 0) {

                showMessage(
                        "Weight must be greater than 0."
                );

                return;
            }

            if (coverage <= 0) {

                showMessage(
                        "Coverage amount must be greater than $0."
                );

                return;
            }

            // Calculate the denominator separately so an invalid division
            // by a value near zero can be prevented.
            double denominator =
                    weight
                            - (4.01 * age);

            if (Math.abs(denominator)
                    < 0.000001) {

                showMessage(
                        "These age and weight values cause an invalid risk calculation."
                );

                return;
            }

            // Calculate the customer's insurance risk factor.
            double riskFactor =
                    InsuranceCalculator
                            .calculateRiskFactor(
                                    age,
                                    height,
                                    weight
                            );

            String riskStatus;

            // Positive risk factors are SAFE; negative factors are UNSAFE.
            if (riskFactor >= 0) {

                riskStatus =
                        "Safe";

            } else {

                riskStatus =
                        "Unsafe";
            }

            // Adjust the risk factor when it is outside the required range.
            double adjustedRiskFactor =
                    InsuranceCalculator
                            .adjustRiskFactor(
                                    riskFactor
                            );

            // Calculate the annual insurance premium.
            double annualPremium =
                    InsuranceCalculator
                            .calculateAnnualPremium(
                                    adjustedRiskFactor,
                                    coverage
                            );

            // Calculate the insurance cost for each $1,000 of coverage.
            double costPerThousand =
                    InsuranceCalculator
                            .calculateCostPerThousand(
                                    annualPremium,
                                    coverage
                            );

            // Initially assume no discount has been applied.
            double discountAmount =
                    0.0;

            double premiumAfterDiscount =
                    annualPremium;

            // Apply a percentage discount when selected.
            if (percentDiscountButton
                    .isSelected()) {

                double percentDiscount =
                        Double.parseDouble(
                                discountAmountField
                                        .getText()
                                        .trim()
                        );

                // Percentage discounts must fall between 0 and 100.
                if (percentDiscount < 0
                        || percentDiscount > 100) {

                    showMessage(
                            "Percentage discount must be between 0 and 100."
                    );

                    return;
                }

                discountAmount =
                        InsuranceCalculator
                                .calculatePercentageDiscount(
                                        annualPremium,
                                        percentDiscount
                                );

                premiumAfterDiscount =
                        annualPremium
                                - discountAmount;
            }

            // Apply a flat-dollar discount when selected.
            else if (flatDiscountButton
                    .isSelected()) {

                discountAmount =
                        Double.parseDouble(
                                discountAmountField
                                        .getText()
                                        .trim()
                        );

                // Flat-dollar discounts cannot be negative.
                if (discountAmount < 0) {

                    showMessage(
                            "Flat dollar discount cannot be negative."
                    );

                    return;
                }

                // The discount cannot exceed the entire annual premium.
                if (discountAmount
                        > annualPremium) {

                    showMessage(
                            "Flat dollar discount cannot be greater than the annual premium."
                    );

                    return;
                }

                premiumAfterDiscount =
                        annualPremium
                                - discountAmount;
            }

            // Calculate sales tax after any discount has been applied.
            double salesTax =
                    InsuranceCalculator
                            .calculateSalesTax(
                                    premiumAfterDiscount
                            );

            // Calculate the final annual policy amount.
            double finalTotal =
                    InsuranceCalculator
                            .calculateFinalTotal(
                                    premiumAfterDiscount,
                                    salesTax
                            );

            // Create a currency formatter for monetary output.
            NumberFormat currency =
                    NumberFormat
                            .getCurrencyInstance();

            // Build the customer's display name.
            String fullName =
                    buildFullName(
                            firstName,
                            middleInitial,
                            lastName
                    );

            // Display all quotation information.
            customerResultLabel.setText(
                    "Customer: "
                            + fullName
            );

            riskFactorResultLabel.setText(
                    String.format(
                            "Risk Factor: %.2f",
                            riskFactor
                    )
            );

            riskStatusResultLabel.setText(
                    "Risk Status: "
                            + riskStatus.toUpperCase()
            );

            coverageResultLabel.setText(
                    "Coverage Amount: "
                            + currency.format(
                            coverage
                    )
            );

            costPerThousandResultLabel.setText(
                    "Cost per $1,000: "
                            + currency.format(
                            costPerThousand
                    )
            );

            annualPremiumResultLabel.setText(
                    "Annual Premium: "
                            + currency.format(
                            annualPremium
                    )
            );

            discountResultLabel.setText(
                    "Discount: "
                            + currency.format(
                            discountAmount
                    )
            );

            salesTaxResultLabel.setText(
                    "Sales Tax (6%): "
                            + currency.format(
                            salesTax
                    )
            );

            finalTotalResultLabel.setText(
                    "FINAL TOTAL: "
                            + currency.format(
                            finalTotal
                    )
            );

        } catch (NumberFormatException ex) {

            // Display an error when numeric input is blank or cannot be
            // converted into the required numeric data type.
            showMessage(
                    "Please enter valid numbers for age, height, weight, coverage, and discount."
            );
        }
    }


    // METHOD NAME:
    // clearForm
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine clears all customer input, policy information, discount
    // information, and calculated quotation results. It restores the form
    // to its original state.
    //
    // PARAMETERS LIST (in Parameter Order):
    // (None)
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private void clearForm() {

        // Clear all customer information.
        firstNameField.setText("");
        middleInitialField.setText("");
        lastNameField.setText("");

        ageField.setText("");
        heightField.setText("");
        weightField.setText("");
        coverageField.setText("");

        // Reset all discount information.
        discountAmountField.setText("");

        noDiscountButton.setSelected(true);

        discountAmountField.setEnabled(false);

        // Restore result labels to their initial values.
        customerResultLabel.setText(
                "Customer:"
        );

        riskFactorResultLabel.setText(
                "Risk Factor:"
        );

        riskStatusResultLabel.setText(
                "Risk Status:"
        );

        coverageResultLabel.setText(
                "Coverage Amount:"
        );

        costPerThousandResultLabel.setText(
                "Cost per $1,000:"
        );

        annualPremiumResultLabel.setText(
                "Annual Premium:"
        );

        discountResultLabel.setText(
                "Discount:"
        );

        salesTaxResultLabel.setText(
                "Sales Tax (6%):"
        );

        finalTotalResultLabel.setText(
                "FINAL TOTAL:"
        );

        // Return keyboard focus to the first customer input field.
        firstNameField.requestFocus();
    }


    // METHOD NAME:
    // buildFullName
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This function creates the customer's formatted full name. If a middle
    // initial was entered, it is converted to uppercase and followed by a
    // period. If no middle initial was entered, only the first and last names
    // are returned.
    //
    // PARAMETERS LIST (in Parameter Order):
    // firstName     - Customer's first name.
    // middleInitial - Customer's optional middle initial.
    // lastName      - Customer's last name.
    //
    // RETURNS:
    // A String containing the customer's formatted full name.
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private String buildFullName(
            String firstName,
            String middleInitial,
            String lastName) {

        // Return the name without a middle initial when one was not entered.
        if (middleInitial.isEmpty()) {

            return firstName
                    + " "
                    + lastName;
        }

        // Include the formatted middle initial when one was supplied.
        return firstName
                + " "
                + middleInitial.toUpperCase()
                + ". "
                + lastName;
    }


    // METHOD NAME:
    // showMessage
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This routine displays a message dialog containing validation or error
    // information for the user.
    //
    // PARAMETERS LIST (in Parameter Order):
    // message - String containing the message that will be displayed.
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    private void showMessage(
            String message) {

        JOptionPane.showMessageDialog(
                frame,
                message
        );
    }
}