/**
 * Provides the calculation logic used by the ChargEm Life Insurance
 * quotation system.
 *
 * <p>This class is responsible for calculating customer risk factors,
 * annual premiums, discounts, sales tax, and final policy totals.</p>
 *
 * @author Rojesh Shrestha
 * @course CS 421
 * @date September 8, 2026
 */
public class InsuranceCalculator {

    /**
     * Sales tax rate applied to the insurance premium after discounts.
     */
    private static final double SALES_TAX_RATE = 0.06;

    /**
     * Calculates the customer's insurance risk factor using age,
     * height, and weight.
     *
     * @param age    customer's age in years
     * @param height customer's height in inches
     * @param weight customer's weight in pounds
     * @return the calculated insurance risk factor
     */
    public static double calculateRiskFactor(
            int age,
            double height,
            double weight) {

        return (
                age
                        + Math.sqrt(
                        (height * height)
                                + (age * weight)
                )
        )
                / (weight - (4.01 * age));
    }

    /**
     * Normalizes a risk factor that falls outside the range of
     * -10 to 10.
     *
     * <p>The value is repeatedly divided by 10 until it falls within
     * the required range.</p>
     *
     * @param riskFactor the original calculated risk factor
     * @return the adjusted risk factor used for premium calculation
     */
    public static double adjustRiskFactor(
            double riskFactor) {

        double adjustedRiskFactor = riskFactor;

        while (adjustedRiskFactor > 10
                || adjustedRiskFactor < -10) {

            adjustedRiskFactor /= 10;
        }

        return adjustedRiskFactor;
    }

    /**
     * Calculates the annual insurance premium using the adjusted
     * risk factor and requested policy coverage amount.
     *
     * @param adjustedRiskFactor the normalized customer risk factor
     * @param coverage           the requested policy coverage amount
     * @return the calculated annual insurance premium
     */
    public static double calculateAnnualPremium(
            double adjustedRiskFactor,
            double coverage) {

        return (
                (10.1 - adjustedRiskFactor)
                        / 10
        )
                * coverage;
    }

    /**
     * Calculates the cost of the policy for each $1,000 of coverage.
     *
     * @param annualPremium the calculated annual premium
     * @param coverage      the requested policy coverage amount
     * @return the cost per $1,000 of coverage
     */
    public static double calculateCostPerThousand(
            double annualPremium,
            double coverage) {

        return annualPremium
                / (coverage / 1000);
    }

    /**
     * Calculates the dollar amount of a percentage-based discount.
     *
     * @param annualPremium   the calculated annual premium
     * @param percentDiscount the discount percentage
     * @return the dollar value of the percentage discount
     */
    public static double calculatePercentageDiscount(
            double annualPremium,
            double percentDiscount) {

        return annualPremium
                * (percentDiscount / 100.0);
    }

    /**
     * Calculates sales tax on the premium after any discount
     * has been applied.
     *
     * @param premiumAfterDiscount the premium remaining after discount
     * @return the calculated sales tax
     */
    public static double calculateSalesTax(
            double premiumAfterDiscount) {

        return premiumAfterDiscount
                * SALES_TAX_RATE;
    }

    /**
     * Calculates the final annual policy total by adding sales tax
     * to the premium after discounts.
     *
     * @param premiumAfterDiscount the premium remaining after discount
     * @param salesTax             the calculated sales tax
     * @return the final annual policy total
     */
    public static double calculateFinalTotal(
            double premiumAfterDiscount,
            double salesTax) {

        return premiumAfterDiscount
                + salesTax;
    }
}