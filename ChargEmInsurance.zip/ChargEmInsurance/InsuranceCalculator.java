// FILENAME: InsuranceCalculator.java
//
// WRITTEN BY: Rojesh Shrestha
// DATE CREATED: September 8, 2026
//
// PART OF PROJECT: ChargEm Life Insurance Policy Quotation System
//
// FILE PURPOSE:
// This file contains the business and mathematical calculations used by the
// ChargEm Life Insurance quotation system.
//
// CLASS NAME:
// InsuranceCalculator
//
// WRITTEN BY: Rojesh Shrestha
// DATE CREATED: September 8, 2026
//
// CLASS PURPOSE:
// This class performs all insurance-related calculations for the application.
// These calculations include the customer's risk factor, risk factor
// adjustment, annual premium, cost per $1,000 of coverage, percentage
// discount, sales tax, and final annual policy total.
//
// CLASS VARIABLE DICTIONARY (in Alphabetical Order):
// SALES_TAX_RATE - Constant double containing the 6% Michigan sales tax rate
//                  applied after discounts.
//
// MODIFICATION HISTORY:
// WHO                 WHEN                WHAT
// ------------------  ------------------  ------------------------------------
// Rojesh Shrestha     September 8, 2026   Initial program implementation
//

public class InsuranceCalculator {

    // CONSTANTS -- CONSTANTS -- CONSTANTS -- CONSTANTS -- CONSTANTS
    // CONSTANTS -- CONSTANTS -- CONSTANTS -- CONSTANTS -- CONSTANTS

    private static final double SALES_TAX_RATE = 0.06;
    // Michigan sales tax rate applied after any discount.

    // METHODS/FUNCTIONS -- METHODS/FUNCTIONS -- METHODS/FUNCTIONS
    // METHODS/FUNCTIONS -- METHODS/FUNCTIONS -- METHODS/FUNCTIONS


    // METHOD NAME:
    // calculateRiskFactor
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This function calculates the customer's insurance risk factor using
    // the customer's age, height, and weight according to the formula
    // specified by ChargEm Life Insurance.
    //
    // PARAMETERS LIST (in Parameter Order):
    // age    - Customer's age in years.
    // height - Customer's height in inches.
    // weight - Customer's weight in pounds.
    //
    // RETURNS:
    // A double containing the calculated insurance risk factor.
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    public static double calculateRiskFactor(
            int age,
            double height,
            double weight) {

        // Calculate and return the customer's insurance risk factor.
        return (
                age
                        + Math.sqrt(
                        (height * height)
                                + (age * weight)
                )
        )
                / (weight - (4.01 * age));
    }


    // METHOD NAME:
    // adjustRiskFactor
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This function adjusts a risk factor that is greater than 10 or less
    // than -10. The value is repeatedly divided by 10 until only one digit
    // remains to the left of the decimal point.
    //
    // PARAMETERS LIST (in Parameter Order):
    // riskFactor - The original customer risk factor.
    //
    // RETURNS:
    // A double containing the adjusted risk factor used for premium
    // calculations.
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // adjustedRiskFactor - Working copy of the risk factor that is repeatedly
    //                      divided by 10 when necessary.
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    public static double adjustRiskFactor(
            double riskFactor) {

        double adjustedRiskFactor = riskFactor;

        // Continue reducing the risk factor until it falls within the
        // required range of -10 through 10.
        while (adjustedRiskFactor > 10
                || adjustedRiskFactor < -10) {

            adjustedRiskFactor /= 10;
        }

        return adjustedRiskFactor;
    }


    // METHOD NAME:
    // calculateAnnualPremium
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This function calculates the customer's annual insurance premium using
    // the adjusted risk factor and the requested policy coverage amount.
    //
    // PARAMETERS LIST (in Parameter Order):
    // adjustedRiskFactor - Adjusted risk factor used in the premium formula.
    // coverage           - Customer's requested policy coverage amount.
    //
    // RETURNS:
    // A double containing the calculated annual insurance premium.
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    public static double calculateAnnualPremium(
            double adjustedRiskFactor,
            double coverage) {

        // Calculate and return the annual insurance premium.
        return (
                (10.1 - adjustedRiskFactor)
                        / 10
        )
                * coverage;
    }


    // METHOD NAME:
    // calculateCostPerThousand
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This function determines the insurance cost for each $1,000 of policy
    // coverage.
    //
    // PARAMETERS LIST (in Parameter Order):
    // annualPremium - Calculated annual insurance premium.
    // coverage      - Customer's requested policy coverage amount.
    //
    // RETURNS:
    // A double containing the insurance cost per $1,000 of coverage.
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    public static double calculateCostPerThousand(
            double annualPremium,
            double coverage) {

        return annualPremium
                / (coverage / 1000);
    }


    // METHOD NAME:
    // calculatePercentageDiscount
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This function calculates the dollar value of a percentage discount
    // applied to the customer's annual premium.
    //
    // PARAMETERS LIST (in Parameter Order):
    // annualPremium   - Customer's calculated annual premium.
    // percentDiscount - Percentage discount entered by the salesperson.
    //
    // RETURNS:
    // A double containing the dollar value of the percentage discount.
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    public static double calculatePercentageDiscount(
            double annualPremium,
            double percentDiscount) {

        return annualPremium
                * (percentDiscount / 100.0);
    }


    // METHOD NAME:
    // calculateSalesTax
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This function calculates Michigan sales tax using the insurance premium
    // remaining after any discount has been applied.
    //
    // PARAMETERS LIST (in Parameter Order):
    // premiumAfterDiscount - Annual premium remaining after discount.
    //
    // RETURNS:
    // A double containing the calculated sales tax amount.
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    public static double calculateSalesTax(
            double premiumAfterDiscount) {

        return premiumAfterDiscount
                * SALES_TAX_RATE;
    }


    // METHOD NAME:
    // calculateFinalTotal
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This function calculates the final annual policy total by adding the
    // sales tax to the insurance premium remaining after discounts.
    //
    // PARAMETERS LIST (in Parameter Order):
    // premiumAfterDiscount - Premium remaining after discount.
    // salesTax             - Calculated Michigan sales tax amount.
    //
    // RETURNS:
    // A double containing the final annual policy total.
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // (None)
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    public static double calculateFinalTotal(
            double premiumAfterDiscount,
            double salesTax) {

        return premiumAfterDiscount
                + salesTax;
    }
}