import javax.swing.SwingUtilities;

/*
 * ChargEm Life Insurance Policy Quotation System
 *
 * Course: CS 421
 * Date: September 8, 2026
 */

/**
 * Serves as the entry point for the ChargEm Life Insurance
 * quotation application.
 *
 * <p>This class starts the graphical user interface on Swing's
 * Event Dispatch Thread to ensure proper Swing application behavior.</p>
 *
 * @author Rojesh Shrestha
 */
public class ChargEmInsurance {

    /**
     * Starts the ChargEm Life Insurance quotation application.
     *
     * @param args command-line arguments; not used by this application
     */
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            InsuranceQuoteGUI gui =
                    new InsuranceQuoteGUI();

            gui.show();
        });
    }
}