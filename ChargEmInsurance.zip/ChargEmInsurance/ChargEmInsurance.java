import javax.swing.SwingUtilities;

// FILENAME: ChargEmInsurance.java
//
// WRITTEN BY: Rojesh Shrestha
// DATE CREATED: September 8, 2026
//
// PART OF PROJECT: ChargEm Life Insurance Policy Quotation System
//
// PROJECT PURPOSE:
// The purpose of this project is to provide ChargEm Life Insurance sales
// representatives with a graphical quotation system. The program collects
// customer information including the customer's name, age, height, weight,
// and desired policy coverage amount. The program then calculates the
// customer's insurance risk factor, determines whether the customer is
// classified as SAFE or UNSAFE, and calculates the annual insurance premium.
//
// The program also allows the sales representative to apply either a
// percentage discount or a flat-dollar discount. After any discount is
// applied, Michigan sales tax is calculated and added to the remaining
// premium to determine the final annual policy total.
//
// FILE PURPOSE:
// This file is the driver for the application. It contains the main method
// that launches the ChargEm Life Insurance graphical user interface.
//
// COMPILATION NOTES:
// This project was successfully compiled and executed in the SE 145 computer
// lab using Java SE / JDK 25. No special compiler options or optimizations
// are required.
//
// The project can be compiled from the command line with:
//
// javac ChargEmInsurance.java InsuranceQuoteGUI.java InsuranceCalculator.java
//
// LIBRARIES AND 3RD PARTY DEPENDENCIES:
// Java SE / JDK 25
// Java Swing
// Java Abstract Window Toolkit (AWT)
//
// No third-party libraries are required.
//
// COMMAND LINE PARAMETER LIST (in Parameter Order):
// (None)
//
// ENVIRONMENTAL RETURNS:
// (Nothing)
//
// SAMPLE INVOCATION:
// Compile:
// javac ChargEmInsurance.java InsuranceQuoteGUI.java InsuranceCalculator.java
//
// Run:
// java ChargEmInsurance
//
// GLOBAL VARIABLE LIST (Alphabetically):
// (None)
//
// MODIFICATION HISTORY:
// WHO                 WHEN                WHAT
// ------------------  ------------------  ------------------------------------
// Rojesh Shrestha     September 8, 2026   Initial program implementation
//

public class ChargEmInsurance {

    // METHOD NAME:
    // main
    //
    // WRITTEN BY: Rojesh Shrestha
    // DATE CREATED: September 8, 2026
    //
    // METHOD PURPOSE:
    // This is the main entry point for the ChargEm Life Insurance quotation
    // application. The graphical interface is created and started on Swing's
    // Event Dispatch Thread.
    //
    // PARAMETERS LIST (in Parameter Order):
    // args - String array containing command-line arguments. This application
    //        does not use command-line arguments.
    //
    // RETURNS:
    // Nothing
    //
    // LOCAL VARIABLE DICTIONARY (in Alphabetical Order):
    // gui - InsuranceQuoteGUI object representing the application's main
    //       graphical user interface.
    //
    // MODIFICATION HISTORY:
    // WHO                 WHEN                WHAT
    // ------------------  ------------------  --------------------------------
    // Rojesh Shrestha     September 8, 2026   Initial implementation
    //
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            // Create the application's graphical user interface.
            InsuranceQuoteGUI gui =
                    new InsuranceQuoteGUI();

            // Display the application window.
            gui.show();
        });
    }
}